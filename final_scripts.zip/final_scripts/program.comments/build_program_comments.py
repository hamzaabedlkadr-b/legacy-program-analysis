#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional


PARA_RE = re.compile(r"^\s*([A-Z][A-Z0-9-]{1,30})\.\s*$")


def normalize_line_fixed_format(raw: str):
    """
    COBOL fixed format:
      cols 1-6: sequence
      col 7: indicator
      cols 8-72: code
    Returns (code, indicator)
    """
    line = raw.rstrip("\n")
    if not line:
        return "", " "

    padded = line + (" " * max(0, 80 - len(line)))
    indicator = padded[6] if len(padded) > 6 else " "
    code = padded[7:72].rstrip()
    return code, indicator


def extract_comments(cobol_path: Path) -> List[Dict]:
    comments = []
    current_para: Optional[str] = None

    for idx, raw in enumerate(cobol_path.read_text(encoding="utf-8", errors="replace").splitlines(), start=1):
        code, indicator = normalize_line_fixed_format(raw)
        up = code.upper()

        # Track paragraph context
        m = PARA_RE.match(up)
        if m:
            current_para = m.group(1).upper()

        # Full-line comment (indicator in col 7)
        if indicator in ("*", "/"):
            txt = code.strip()
            if txt:
                comments.append({
                    "line": idx,
                    "paragraph": current_para,
                    "text": txt,
                    "kind": "full_line",
                })
            continue

        # Inline comment using *> in code area
        if "*>".upper() in up:
            parts = code.split("*>", 1)
            txt = parts[1].strip() if len(parts) > 1 else ""
            if txt:
                comments.append({
                    "line": idx,
                    "paragraph": current_para,
                    "text": txt,
                    "kind": "inline",
                })

    return comments


def main():
    ap = argparse.ArgumentParser(description="Build program.comments.json from a COBOL file")
    ap.add_argument("--cobol", required=True, help="Path to COBOL .CBL file")
    ap.add_argument("--program", required=True, help="Program name")
    ap.add_argument("--output", required=True, help="Output program.comments.json path")
    args = ap.parse_args()

    cobol_path = Path(args.cobol)
    comments = extract_comments(cobol_path)

    out = {
        "type": "program.comments",
        "program": args.program,
        "source": str(cobol_path),
        "count": len(comments),
        "comments": comments,
    }

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[OK] Wrote {out_path}")


if __name__ == "__main__":
    main()
