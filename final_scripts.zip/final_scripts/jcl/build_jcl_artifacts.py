#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path
from typing import Dict, List


JOB_RE = re.compile(r"^//(\w+)\s+JOB\b", re.IGNORECASE)
EXEC_RE = re.compile(r"^//(\w+)\s+EXEC\b(.*)$", re.IGNORECASE)
DD_RE = re.compile(r"^//(\w+)\s+DD\b(.*)$", re.IGNORECASE)
PGM_RE = re.compile(r"PGM=([A-Z0-9$#@._-]+)", re.IGNORECASE)
PROC_RE = re.compile(r"PROC=([A-Z0-9$#@._-]+)", re.IGNORECASE)
DSN_RE = re.compile(r"DSN=([^,\s)]+)", re.IGNORECASE)
DISP_RE = re.compile(r"DISP=([^,\s)]+)", re.IGNORECASE)


def safe_name(text: str) -> str:
    return re.sub(r"[^A-Z0-9-]+", "_", text.upper()).strip("_") or "ITEM"


def parse_jcl(path: Path) -> Dict:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    job_name = None
    steps: List[Dict] = []
    current_step = None

    for raw in lines:
        line = raw.rstrip()
        if not line:
            continue
        if line.startswith("//*"):
            continue

        m = JOB_RE.match(line)
        if m:
            job_name = m.group(1).upper()
            continue

        m = EXEC_RE.match(line)
        if m:
            step_name = m.group(1).upper()
            rest = m.group(2)
            pgm = None
            proc = None
            m_pgm = PGM_RE.search(rest)
            if m_pgm:
                pgm = m_pgm.group(1).upper()
            m_proc = PROC_RE.search(rest)
            if m_proc:
                proc = m_proc.group(1).upper()

            current_step = {
                "step": step_name,
                "program": pgm,
                "proc": proc,
                "dds": [],
            }
            steps.append(current_step)
            continue

        m = DD_RE.match(line)
        if m and current_step is not None:
            ddname = m.group(1).upper()
            rest = m.group(2)
            dsn = None
            disp = None
            m_dsn = DSN_RE.search(rest)
            if m_dsn:
                dsn = m_dsn.group(1)
            m_disp = DISP_RE.search(rest)
            if m_disp:
                disp = m_disp.group(1)
            current_step["dds"].append({
                "ddname": ddname,
                "dsn": dsn,
                "disp": disp,
                "raw": line.strip(),
            })

    programs = sorted({s["program"] for s in steps if s.get("program")})
    datasets = []
    for s in steps:
        for d in s.get("dds", []):
            if d.get("dsn"):
                datasets.append(d["dsn"])
    datasets = sorted(set(datasets))

    return {
        "job_name": job_name or path.stem.upper(),
        "programs": programs,
        "steps": steps,
        "datasets": datasets,
    }


def main():
    ap = argparse.ArgumentParser(description="Build JCL artifacts from a .jcl file")
    ap.add_argument("--jcl", required=True, help="Path to JCL file")
    ap.add_argument("--output-dir", required=True, help="Output directory for JCL artifacts")
    args = ap.parse_args()

    jcl_path = Path(args.jcl)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    data = parse_jcl(jcl_path)
    job = data["job_name"]

    summary = {
        "type": "jcl.summary",
        "job": job,
        "source": str(jcl_path),
        "programs": data["programs"],
        "steps_count": len(data["steps"]),
        "datasets_count": len(data["datasets"]),
    }

    (out_dir / "jcl.summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # Per-step files
    for step in data["steps"]:
        fname = f"jcl.steps.{safe_name(step['step'])}.json"
        doc = {
            "type": "jcl.steps",
            "job": job,
            "step": step["step"],
            "program": step.get("program"),
            "proc": step.get("proc"),
            "dds": step.get("dds", []),
            "source": str(jcl_path),
        }
        (out_dir / fname).write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")

    # Per-dataset files
    for dsn in data["datasets"]:
        fname = f"jcl.datasets.{safe_name(dsn)}.json"
        doc = {
            "type": "jcl.datasets",
            "job": job,
            "dsn": dsn,
            "source": str(jcl_path),
        }
        (out_dir / fname).write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"[OK] Wrote JCL artifacts to {out_dir}")


if __name__ == "__main__":
    main()
